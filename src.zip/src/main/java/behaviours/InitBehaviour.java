package behaviours;

import javax.swing.JFrame;

import gla.joose.birdsim.boards.Board;

public interface InitBehaviour {
	public void doInitBoard(JFrame frame,Board b);
	

}
