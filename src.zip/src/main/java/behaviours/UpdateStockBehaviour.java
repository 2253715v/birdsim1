package behaviours;

import gla.joose.birdsim.boards.Board;

public interface UpdateStockBehaviour {
	public void doUpdateStock(Board b);
	
}
