package behaviours;

import gla.joose.birdsim.boards.Board;

public interface FlyBehaviour {
	public void fly(Board b);
}
